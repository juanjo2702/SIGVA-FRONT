import{i as a,be as r}from"./index-Cv88sRu-.js";function s(){return a(r)}export{s as u};
