import{i as a,bd as r}from"./index-tqutsHZU.js";function u(){return a(r)}export{u};
