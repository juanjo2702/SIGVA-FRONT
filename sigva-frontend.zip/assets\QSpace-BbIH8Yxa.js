import{c as a,d as s}from"./index-Cv88sRu-.js";const p=a({name:"QSpace",setup(){const e=s("div",{class:"q-space"});return()=>e}});export{p as Q};
