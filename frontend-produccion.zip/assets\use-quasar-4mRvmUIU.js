import{i as a,bc as r}from"./index-LFkrHSsK.js";function u(){return a(r)}export{u};
