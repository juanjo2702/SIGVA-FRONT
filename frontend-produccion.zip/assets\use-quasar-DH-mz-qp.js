import{i as a,bc as r}from"./index-CmHRonlf.js";function u(){return a(r)}export{u};
